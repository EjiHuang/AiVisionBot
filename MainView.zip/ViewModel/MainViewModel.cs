﻿using CaptureCore;
using Composition.WindowsRuntimeHelpers;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using MainView.Framwork;
using MainView.Model;
using System;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace MainView.ViewModel
{
    public class MainViewModel : ViewModelBase
    {
        public MainViewModel()
        {
            Initialize();
        }

        #region public properties

        /// <summary>
        /// Process list collection.
        /// </summary>
        public ObservableCollection<ProcessModel> ProcessInfoes { get; set; }

        /// <summary>
        /// Process index.
        /// </summary>
        public int ProcessIndex
        {
            get => GetProperty(() => ProcessIndex);
            set => SetProperty(() => ProcessIndex, value);
        }

        /// <summary>
        /// Basic sample application.
        /// </summary>
        public BasicApplication Capturer
        {
            get => GetProperty(() => Capturer);
            set => SetProperty(() => Capturer, value);
        }

        #endregion

        #region public methods

        /// <summary>
        /// Get current system process list.
        /// </summary>
        public void GetProcessList()
        {
            // Get high priority.
            Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.High;

            // Clear list.
            if (ProcessInfoes.Count > 0)
                ProcessInfoes.Clear();

            // Get process list.
            EnumProcessHelper ph = new EnumProcessHelper();
            foreach (var p in ph.EnumWindows())
            {
                ProcessInfoes.Add(new ProcessModel
                {
                    ProcessName = p.ProcessName + ".exe",
                    ProcessId = p.ProcessId,
                    ProcessWindowTitle = p.ProcessWindowTitle,
                    ProcessIcon = p.ProcessIcon,
                    MainWindowHandle = p.MainWindowHandle
                });
            }
        }

        [AsyncCommand]
        public void StartCaptureCommand()
        {
            if (ProcessIndex >= 0)
            {
                var p = ProcessInfoes[ProcessIndex];
                Debug.WriteLine($"Selected: {p.ProcessName}");
                StopCapture();
                var hwnd = p.MainWindowHandle;
                try
                {
                    StartHwndCapture(hwnd);
                }
                catch (Exception e)
                {
                    if (IntPtr.Size == 8)
                    {
                        Debug.WriteLine($"Hwnd 0x{hwnd.ToInt64():X16} is not valid for capture!");
                    }
                    else
                    {
                        Debug.WriteLine($"Hwnd 0x{hwnd.ToInt32():X8} is not valid for capture!");
                    }
                    Debug.WriteLine(e.ToString());
                    Debug.WriteLine(e.StackTrace);
                    ProcessInfoes.Remove(p);
                }
            }
        }

        [AsyncCommand]
        public void StopCaptureCommand()
        {
            Debug.WriteLine("OnStopCapturing");
            StopCapture();
        }

        #endregion

        #region private methods

        /// <summary>
        /// Initialize method.
        /// </summary>
        private void Initialize()
        {
            // Initialize process list.
            ProcessInfoes = new ObservableCollection<ProcessModel>();
            // Get process list.
            GetProcessList();
        }

        /// <summary>
        /// Start hwnd capture.
        /// </summary>
        /// <param name="hwnd"></param>
        private void StartHwndCapture(IntPtr hwnd)
        {
            var item = CaptureHelper.CreateItemForWindow(hwnd);
            if (item != null)
            {
                Capturer.StartCaptureFromItem(item);
            }
        }

        /// <summary>
        /// Stop capture.
        /// </summary>
        private void StopCapture() => Capturer?.StopCapture();

        #endregion

    }
}
