﻿using CaptureCore;
using Composition.WindowsRuntimeHelpers;
using System;
using System.Numerics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using Windows.Graphics.Capture;
using Windows.UI.Composition;

namespace MainView
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window, IDisposable
    {
        private bool disposed;
        private BasicApplication capturer;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void ProcessListComBox_DropDownOpened(object sender, EventArgs e)
        {
            MainVM.GetProcessList();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void CompositionHost_Loaded(object sender, RoutedEventArgs e)
        {
            capturer = new BasicApplication(CompositionHost.Compositor);
            CompositionHost.SetChild(capturer.Visual);
            var viewModel = MainVM;
            viewModel.Capturer = capturer;
        }

        private void CompositionHost_Unloaded(object sender, RoutedEventArgs e)
        {
            Dispose(true);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    capturer?.Dispose();
                    capturer = null;
                    var viewModel = MainVM;
                    viewModel.Capturer = null;
                }

                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Dispose(true);
        }
    }
}
